export default function HRPage() {
  return (
    <div>
      <h1>Tools for HR Teams</h1>
      <p>Automated tracking, reporting, and employee compliance monitoring.</p>
    </div>
  );
}
