export default function InstructorsAdmin() {
  return (
    <div>
      <h1>Instructor Management</h1>
      <p>Assign roles and manage instructor access.</p>
    </div>
  );
}
