export default function SupportTickets() {
  return (
    <div>
      <h1>Support Tickets</h1>
      <p>View and resolve customer issues.</p>
    </div>
  );
}
