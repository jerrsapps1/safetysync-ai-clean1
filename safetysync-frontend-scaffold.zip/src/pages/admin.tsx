import { useAuth } from '../hooks/useAuth';

export default function AdminDashboard() {
  const { isAuthenticated } = useAuth();

  return isAuthenticated ? (
    <div>
      <h1>Admin Dashboard</h1>
    </div>
  ) : (
    <div>Please log in to access the admin panel.</div>
  );
}
