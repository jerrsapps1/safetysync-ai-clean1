import { useRouter } from 'next/router';

export default function InstructorPortal() {
  const { query } = useRouter();
  const { id } = query;

  return (
    <div>
      <h1>Instructor Portal: {id}</h1>
      <p>Class tracking and certificate tools</p>
    </div>
  );
}
