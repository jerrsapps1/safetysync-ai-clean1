export default function HomePage() {
  return (
    <div>
      <h1>Welcome to SafetySync.ai</h1>
      <p>Compliance automation for training and certification.</p>
    </div>
  );
}
